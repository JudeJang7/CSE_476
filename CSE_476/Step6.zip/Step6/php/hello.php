<!DOCTYPE html>
<html>
<head>
    <title>Hello</title>
</head>
<body>
<p><?php echo "Hello from PHP" ?></p>
</body>
</html>