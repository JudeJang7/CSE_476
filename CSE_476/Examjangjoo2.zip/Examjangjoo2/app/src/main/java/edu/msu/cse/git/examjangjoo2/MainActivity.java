package edu.msu.cse.git.examjangjoo2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GestureDetectorCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener {

    private GestureDetectorCompat gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Instantiate the gesture detector for us and we are the listener
         gestureDetector = new GestureDetectorCompat(this, this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        // Be sure to call the superclass implementation
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onDown(MotionEvent event) {
        return true;
    }

    @Override
    public boolean onFling(MotionEvent event1, MotionEvent event2, float velocityX, float velocityY) {
        PuzzleView view = (PuzzleView) findViewById(R.id.puzzleView);

        float absX = Math.abs(velocityX);
        float absY = Math.abs(velocityY);

        if (absX > absY){
            if (velocityX > 0){
                view.onFlingRight();
            }
            else if (velocityX < 0){
                view.onFlingLeft();
            }
        }

        else if (absY > absX){
            if (velocityY > 0){
                view.onFlingDown();
            }
            else if (velocityY < 0){
                view.onFlingUp();
            }
        }

        return true;
    }

    @Override
    public void onLongPress(MotionEvent event) {
    }

    @Override
    public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
        return true;
    }

    @Override
    public void onShowPress(MotionEvent event) {
    }

    @Override
    public boolean onSingleTapUp(MotionEvent event) {
        return true;
    }

    public void newGame(View view) {
        ((PuzzleView)findViewById(R.id.puzzleView)).restart();
    }
}
