package edu.msu.cse.git.examjangjoo2;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;

import androidx.core.view.GestureDetectorCompat;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Puzzle {
    /**
     * Paint for filling the area the puzzle is in
     */
    private Paint fillPaint;

    /**
     * Percentage of the display width or height that
     * is occupied by the puzzle.
     */
    final static float SCALE_IN_VIEW = 0.8f;

    int[][] pieces ={ {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0} };

    public Puzzle(Context context) {

        // Create paint for filling the area the puzzle will
        // be solved in.
        fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        fillPaint.setColor(0xffcccccc);

        int position1 = getRandom();
        int position2 = getRandom();

        if (position1 == position2){
            if (position2 == 15){
                position2 -= 1;
            }
            else if (position2 == 0){
                position2 -= 1;
            }
            else {
                position2 += 1;
            }
        }

        int p = 0;
        while(p <= position1) {
            for (int j = 0; j < 4; j++) {
                for (int i = 0; i < 4; i++) {
                    if (p == position1){
                        pieces[i][j] = 2;
                    }
                    p += 1;
                }
            }
        }

        int p2 = 0;
        while(p2 <= position2) {
            for (int j = 0; j < 4; j++) {
                for (int i = 0; i < 4; i++) {
                    if (p2 == position2){
                        pieces[i][j] = 2;
                    }
                    p2 += 1;
                }
            }
        }

    }

    public void draw(Canvas canvas) {

        int wid = canvas.getWidth();
        int hit = canvas.getHeight();

        // Determine the minimum of the two dimensions
        int minDim = wid < hit ? wid : hit;

        int puzzleSize = (int)(minDim * SCALE_IN_VIEW);

        // Fixes rounding of board
        puzzleSize = puzzleSize / 4;
        puzzleSize = puzzleSize * 4;

        // Compute the margins so we center the puzzle
        int marginX = (wid - puzzleSize) / 2;
        int marginY = (hit - puzzleSize) / 2;

        //
        // Draw the outline of the puzzle
        //

        canvas.drawRect(marginX, marginY, marginX + puzzleSize, marginY + puzzleSize, fillPaint);

        int currentLeft = marginX;
        int currentTop = marginY;
        int currentRight = marginX;
        int currentBottom = marginY;
        int tileSize = puzzleSize/4;

        Paint outlinePaint;
        Paint paint2;
        Paint paint4;
        Paint paint8;
        Paint paint16;
        Paint paint32;
        Paint paint64;
        Paint paint128;
        Paint paint256;
        Paint paint512;
        Paint paint1024;
        Paint paint2048;
        Paint paintBeyond;
        Paint paintNumber;

        outlinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint4 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint8 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint16 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint32 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint64 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint128 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint256 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint512 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint1024 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint2048 = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintBeyond = new Paint(Paint.ANTI_ALIAS_FLAG);
        paintNumber = new Paint(Paint.ANTI_ALIAS_FLAG);

        outlinePaint.setStyle(Paint.Style.STROKE);
        paint2.setColor(0xfff2aab9);
        paint4.setColor(0xffe8aabe);
        paint8.setColor(0xffdeaac3);
        paint16.setColor(0xffd3aac7);
        paint32.setColor(0xffc9a9cc);
        paint64.setColor(0xffbfa9d1);
        paint128.setColor(0xffb4a9d5);
        paint256.setColor(0xffaaa9da);
        paint512.setColor(0xffa0a9df);
        paint1024.setColor(0xff96a8e4);
        paint2048.setColor(0xff8ba8e8);
        paintBeyond.setColor(0xff81a8ed);
        paintNumber.setColor(0xff000000);

        Paint currentPaint = fillPaint;

        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++) {

                if (pieces[i][j] != 0){
                    if (pieces[i][j] == 2){
                        currentPaint = paint2;
                    }
                    if (pieces[i][j] == 4){
                        currentPaint = paint4;
                    }
                    if (pieces[i][j] == 8){
                        currentPaint = paint8;
                    }
                    if (pieces[i][j] == 16){
                        currentPaint = paint16;
                    }
                    if (pieces[i][j] == 32){
                        currentPaint = paint32;
                    }
                    if (pieces[i][j] == 64){
                        currentPaint = paint64;
                    }
                    if (pieces[i][j] == 128){
                        currentPaint = paint128;
                    }
                    if (pieces[i][j] == 256){
                        currentPaint = paint256;
                    }
                    if (pieces[i][j] == 512){
                        currentPaint = paint512;
                    }
                    if (pieces[i][j] == 1024){
                        currentPaint = paint1024;
                    }
                    if (pieces[i][j] == 2048){
                        currentPaint = paint2048;
                    }
                    if (pieces[i][j] > 2048){
                        currentPaint = paintBeyond;
                    }

                    canvas.drawRect(currentLeft , currentTop, currentRight + tileSize, currentBottom + tileSize, currentPaint);
                    canvas.drawRect(currentLeft , currentTop, currentRight + tileSize, currentBottom + tileSize, outlinePaint);

                    paintNumber.setTextSize(75);
                    paintNumber.setTextAlign(Paint.Align.CENTER);

                    int number = pieces[i][j];
                    String string = Integer.toString(number);

                    canvas.drawText(string, currentLeft + tileSize / 2, currentTop + tileSize / 1.5f, paintNumber);
                }

                currentLeft = currentRight + tileSize;
                currentRight  += tileSize;

            }

            currentTop = currentBottom + tileSize;
            currentBottom += tileSize;
            currentLeft = marginX;
            currentRight = marginX;

        }

    }

    public int getRandom(){

        Random r = new Random();
        int random = r.nextInt(16);

        return random;
    }


    public void flingRight(){

        List<Integer> list = new ArrayList<Integer>();

        int index = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (pieces[i][j] == 0){
                    list.add(index);
                }
                index += 1;
            }
        }

        Random random = new Random();
        int listSize = list.size();
        int randomIndex = random.nextInt(listSize);
        int position = list.get(randomIndex);

        int p = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (p == position){
                    pieces[i][j] = 2;
                }
                p += 1;
            }
        }

    }

    public void flingLeft(){

        List<Integer> list = new ArrayList<Integer>();

        int index = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (pieces[i][j] == 0){
                    list.add(index);
                }
                index += 1;
            }
        }

        Random random = new Random();
        int listSize = list.size();
        int randomIndex = random.nextInt(listSize);
        int position = list.get(randomIndex);

        int p = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (p == position){
                    pieces[i][j] = 2;
                }
                p += 1;
            }
        }

    }

    public void flingDown(){

        List<Integer> list = new ArrayList<Integer>();

        int index = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (pieces[i][j] == 0){
                    list.add(index);
                }
                index += 1;
            }
        }

        Random random = new Random();
        int listSize = list.size();
        int randomIndex = random.nextInt(listSize);
        int position = list.get(randomIndex);

        int p = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (p == position){
                    pieces[i][j] = 2;
                }
                p += 1;
            }
        }

    }

    public void flingUp(){

        List<Integer> list = new ArrayList<Integer>();

        int index = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (pieces[i][j] == 0){
                    list.add(index);
                }
                index += 1;
            }
        }

        Random random = new Random();
        int listSize = list.size();
        int randomIndex = random.nextInt(listSize);
        int position = list.get(randomIndex);

        int p = 0;
        for (int i = 0; i < 4; i++){
            for (int j = 0; j < 4; j++){
                if (p == position){
                    pieces[i][j] = 2;
                }
                p += 1;
            }
        }

    }

}
