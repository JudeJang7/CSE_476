package edu.msu.jangjoo2.cloudhatter;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDialogFragment;

import edu.msu.jangjoo2.cloudhatter.Cloud.Cloud;
import edu.msu.jangjoo2.cloudhatter.Cloud.Models.Hat;

public class DeletingDlg extends AppCompatDialogFragment {

    private AlertDialog dlg;

    public String getCatId() {
        return catId;
    }

    public void setCatId(String catId) {
        this.catId = catId;
    }

    /**
     * Id for the image we are loading
     */
    private String catId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    /**
     * Set true if we want to cancel
     */
    private volatile boolean cancel = false;

    private final static String ID = "id";

    private final static String NAME = "name";

    /**
     * Save the instance state
     */
    @Override
    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);

        bundle.putString(ID, catId);
        bundle.putString(NAME, name);
    }

    /**
     * Called when the view is destroyed.
     */
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        cancel = true;
    }

    /**
     * Create the dialog box
     */
    @Override
    public Dialog onCreateDialog(Bundle bundle) {

        if(bundle != null) {
            catId = bundle.getString(ID);
            name = bundle.getString(NAME);
        }

        cancel = false;

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        // Set the title
        builder.setTitle(R.string.deleting);

        String confirmation = getString(R.string.deleting_confirmation);
        builder.setMessage(confirmation + ' ' + name + '?');

        builder.setNegativeButton(android.R.string.cancel,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        cancel = true;
                    }
                });

        builder.setPositiveButton(android.R.string.ok,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        delete(name);
                    }
                });

        // Get a reference to the view we are going to load into
        final HatterView view = (HatterView)getActivity().findViewById(R.id.hatterView);

        dlg = builder.create();

        return dlg;
    }

    /**
     * Actually save the hatting
     * @param name name to save it under
     */
    private void delete(final String name) {

        if (!(getActivity() instanceof HatterActivity)) {
            return;
        }
        final HatterActivity activity = (HatterActivity) getActivity();
        final HatterView view = (HatterView) activity.findViewById(R.id.hatterView);

        /*
         * Create a thread to load the hatting from the cloud
         */
        new Thread(new Runnable() {

            @Override
            public void run() {
                // Create a cloud object and get the XML
                Cloud cloud = new Cloud();
                Hat hat = cloud.deleteFromCloud(catId);

                if(cancel) {
                    return;
                }

                // Test for an error
                boolean fail = hat == null;
                if(!fail) {
                    view.loadHat(hat);
                    return;
                }

                final boolean fail1 = fail;
                view.post(new Runnable() {

                    @Override
                    public void run() {
                        dlg.dismiss();
                        if(!fail1) {
                            Toast.makeText(view.getContext(),
                                    R.string.deleting_fail,
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            // Success!
                            if(getActivity() instanceof HatterActivity) {
                                ((HatterActivity)getActivity()).updateUI();
                            }
                            Toast.makeText(view.getContext(),
                            R.string.deleting_success,
                            Toast.LENGTH_SHORT).show();
                        }

                    }

                });

            }
        }).start();

    }


}